/* ════════════════════════════════════════════════════════════
   SERVICE WORKER — BoutiqueNtazimba PWA
   Gère le cache hors-ligne et les notifications push
════════════════════════════════════════════════════════════ */

const SW_VERSION   = 'bn-v1.0.0';
const CACHE_NAME   = 'boutique-ntazimba-' + SW_VERSION;

/* Fichiers à mettre en cache pour fonctionner hors-ligne */
const ASSETS_CACHE = [
  './landing_page.html',
  './boutique_fixed.html',
  './admin_messaging.html',
  './suivi_commande.html',
  './manifest.json',
  './icons/icon-192.png',
  './icons/icon-512.png',
];

/* ── INSTALLATION : mise en cache des fichiers ── */
self.addEventListener('install', event => {
  console.log('[SW] Installation v' + SW_VERSION);
  event.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return Promise.allSettled(
        ASSETS_CACHE.map(url =>
          cache.add(url).catch(e => console.warn('[SW] Cache miss:', url, e.message))
        )
      );
    }).then(() => self.skipWaiting())
  );
});

/* ── ACTIVATION : nettoyage des anciens caches ── */
self.addEventListener('activate', event => {
  console.log('[SW] Activation v' + SW_VERSION);
  event.waitUntil(
    caches.keys().then(keys =>
      Promise.all(
        keys.filter(k => k !== CACHE_NAME).map(k => {
          console.log('[SW] Suppression ancien cache:', k);
          return caches.delete(k);
        })
      )
    ).then(() => self.clients.claim())
  );
});

/* ── FETCH : stratégie Network-First avec fallback cache ── */
self.addEventListener('fetch', event => {
  const { request } = event;
  const url = new URL(request.url);

  /* Ignorer les requêtes externes (images Unsplash, CDN, etc.) */
  if (url.origin !== self.location.origin) {
    event.respondWith(
      fetch(request).catch(() => {
        /* Image de secours si hors-ligne */
        if (request.destination === 'image') {
          return new Response(
            `<svg xmlns="http://www.w3.org/2000/svg" width="200" height="200"><rect width="200" height="200" fill="#f0f4f8"/><text x="100" y="110" text-anchor="middle" fill="#94a3b8" font-size="14">Hors ligne</text></svg>`,
            { headers: { 'Content-Type': 'image/svg+xml' } }
          );
        }
      })
    );
    return;
  }

  /* Pour les fichiers HTML/JS/CSS → Network First, Cache Fallback */
  event.respondWith(
    fetch(request)
      .then(response => {
        /* Mettre à jour le cache si réponse OK */
        if (response.ok) {
          const clone = response.clone();
          caches.open(CACHE_NAME).then(cache => cache.put(request, clone));
        }
        return response;
      })
      .catch(() => {
        /* Hors-ligne → servir depuis le cache */
        return caches.match(request).then(cached => {
          if (cached) return cached;
          /* Page de secours hors-ligne */
          return new Response(
            `<!DOCTYPE html>
            <html lang="fr"><head><meta charset="UTF-8">
            <meta name="viewport" content="width=device-width,initial-scale=1">
            <title>Hors ligne — BoutiqueNtazimba</title>
            <style>
              body{font-family:system-ui,sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#f0f4f8;text-align:center;padding:2rem}
              .box{background:white;border-radius:20px;padding:2.5rem 2rem;max-width:340px;box-shadow:0 8px 40px rgba(0,0,0,.12)}
              .icon{font-size:3.5rem;display:block;margin-bottom:1rem}
              h1{color:#1a3c5e;font-size:1.4rem;margin-bottom:.6rem}
              p{color:#64748b;font-size:14px;line-height:1.6;margin-bottom:1.4rem}
              button{background:#1a3c5e;color:white;border:none;padding:13px 28px;border-radius:99px;font-size:14px;font-weight:600;cursor:pointer;width:100%}
            </style></head>
            <body>
              <div class="box">
                <span class="icon">📶</span>
                <h1>Vous êtes hors ligne</h1>
                <p>Connectez-vous à Internet pour accéder à BoutiqueNtazimba.<br>Vos données locales restent sauvegardées.</p>
                <button onclick="location.reload()">🔄 Réessayer</button>
              </div>
            </body></html>`,
            { headers: { 'Content-Type': 'text/html; charset=utf-8' } }
          );
        });
      })
  );
});

/* ── SYNC EN ARRIÈRE-PLAN (Background Sync) ── */
self.addEventListener('sync', event => {
  console.log('[SW] Background sync:', event.tag);
  if (event.tag === 'sync-orders') {
    event.waitUntil(syncOrders());
  }
});

async function syncOrders() {
  /* Synchronise les commandes en attente quand la connexion revient */
  const cache  = await caches.open('bn-pending');
  const keys   = await cache.keys();
  for (const req of keys) {
    const res = await cache.match(req);
    if (!res) continue;
    try {
      const body = await res.json();
      await fetch(req, { method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify(body) });
      await cache.delete(req);
      console.log('[SW] Commande synchronisée:', req.url);
    } catch(e) {
      console.warn('[SW] Sync échouée, réessai plus tard:', e.message);
    }
  }
}

/* ── NOTIFICATIONS PUSH ── */
self.addEventListener('push', event => {
  if (!event.data) return;
  let data = {};
  try { data = event.data.json(); } catch { data = { title:'BoutiqueNtazimba', body: event.data.text() }; }

  event.waitUntil(
    self.registration.showNotification(data.title || 'BoutiqueNtazimba', {
      body   : data.body    || 'Nouvelle notification',
      icon   : './icons/icon-192.png',
      badge  : './icons/icon-96.png',
      tag    : data.tag     || 'bn-notif',
      data   : data.url     || './',
      vibrate: [200, 100, 200],
      actions: data.actions || [],
    })
  );
});

self.addEventListener('notificationclick', event => {
  event.notification.close();
  const url = event.notification.data || './';
  event.waitUntil(
    clients.matchAll({ type:'window', includeUncontrolled:true }).then(list => {
      for (const client of list) {
        if (client.url.includes(url) && 'focus' in client) return client.focus();
      }
      return clients.openWindow(url);
    })
  );
});

/* ── MESSAGE depuis la page ── */
self.addEventListener('message', event => {
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
  if (event.data?.type === 'GET_VERSION')  event.ports[0]?.postMessage({ version: SW_VERSION });
});

console.log('[SW] BoutiqueNtazimba Service Worker ' + SW_VERSION + ' chargé.');
