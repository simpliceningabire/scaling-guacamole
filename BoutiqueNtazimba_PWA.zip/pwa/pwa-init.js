/* ════════════════════════════════════════════════════════════
   PWA INIT — BoutiqueNtazimba
   Inclure ce script dans toutes les pages HTML :
   <script src="pwa-init.js"></script>
════════════════════════════════════════════════════════════ */

(function () {
  'use strict';

  /* ── 1. Enregistrer le Service Worker ── */
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('./sw.js', { scope: './' })
        .then(reg => {
          console.log('[PWA] Service Worker enregistré :', reg.scope);

          /* Détecter une mise à jour disponible */
          reg.addEventListener('updatefound', () => {
            const newSW = reg.installing;
            newSW.addEventListener('statechange', () => {
              if (newSW.state === 'installed' && navigator.serviceWorker.controller) {
                showUpdateBanner();
              }
            });
          });
        })
        .catch(err => console.warn('[PWA] SW non enregistré :', err));
    });
  }

  /* ── 2. Bannière "Installer l'application" ── */
  let deferredPrompt = null;

  window.addEventListener('beforeinstallprompt', e => {
    e.preventDefault();
    deferredPrompt = e;
    showInstallBanner();
  });

  window.addEventListener('appinstalled', () => {
    hideBanner('bn-install-banner');
    deferredPrompt = null;
    showToastPWA('🎉 Application installée avec succès !');
    /* Sauvegarder l'état installé */
    localStorage.setItem('bn_pwa_installed', '1');
  });

  function showInstallBanner() {
    if (localStorage.getItem('bn_pwa_installed') === '1') return;
    if (localStorage.getItem('bn_install_dismissed') === '1') return;
    if (document.getElementById('bn-install-banner')) return;

    const banner = document.createElement('div');
    banner.id    = 'bn-install-banner';
    banner.innerHTML = `
      <div style="
        position:fixed;bottom:0;left:0;right:0;z-index:9999;
        background:#1a3c5e;color:white;padding:14px 16px;
        display:flex;align-items:center;gap:12px;
        box-shadow:0 -4px 24px rgba(0,0,0,.25);
        animation:slideUpBanner .4s ease;
        font-family:system-ui,sans-serif;
      ">
        <span style="font-size:2rem;flex-shrink:0">🛍️</span>
        <div style="flex:1;min-width:0">
          <div style="font-size:14px;font-weight:700;margin-bottom:2px">Installer BoutiqueNtazimba</div>
          <div style="font-size:12px;opacity:.8">Accès rapide · Fonctionne hors ligne · Données sauvegardées</div>
        </div>
        <div style="display:flex;gap:8px;flex-shrink:0">
          <button id="bn-install-btn" style="
            background:#c9a84c;color:#1a3c5e;border:none;
            padding:9px 16px;border-radius:99px;
            font-weight:700;font-size:13px;cursor:pointer;
            white-space:nowrap;
          ">Installer</button>
          <button id="bn-dismiss-btn" style="
            background:rgba(255,255,255,.15);color:white;border:none;
            width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:18px;
            display:flex;align-items:center;justify-content:center;
          ">×</button>
        </div>
      </div>
      <style>
        @keyframes slideUpBanner{from{transform:translateY(100%)}to{transform:translateY(0)}}
      </style>
    `;
    document.body.appendChild(banner);

    document.getElementById('bn-install-btn').addEventListener('click', async () => {
      if (!deferredPrompt) return;
      deferredPrompt.prompt();
      const { outcome } = await deferredPrompt.userChoice;
      if (outcome === 'accepted') hideBanner('bn-install-banner');
      deferredPrompt = null;
    });

    document.getElementById('bn-dismiss-btn').addEventListener('click', () => {
      hideBanner('bn-install-banner');
      localStorage.setItem('bn_install_dismissed', '1');
    });
  }

  /* ── 3. Bannière de mise à jour disponible ── */
  function showUpdateBanner() {
    if (document.getElementById('bn-update-banner')) return;
    const banner = document.createElement('div');
    banner.id = 'bn-update-banner';
    banner.innerHTML = `
      <div style="
        position:fixed;top:0;left:0;right:0;z-index:9999;
        background:#2e9e5e;color:white;padding:12px 16px;
        display:flex;align-items:center;gap:12px;
        font-family:system-ui,sans-serif;font-size:13px;
        box-shadow:0 4px 20px rgba(0,0,0,.2);
      ">
        <span style="font-size:1.3rem">🔄</span>
        <span style="flex:1">Mise à jour disponible !</span>
        <button onclick="window.location.reload()" style="
          background:white;color:#2e9e5e;border:none;
          padding:7px 16px;border-radius:99px;
          font-weight:700;font-size:12px;cursor:pointer;
        ">Mettre à jour</button>
        <button onclick="document.getElementById('bn-update-banner').remove()" style="
          background:none;border:none;color:white;font-size:20px;cursor:pointer;padding:0 4px;
        ">×</button>
      </div>
    `;
    document.body.appendChild(banner);
  }

  /* ── 4. Indicateur hors-ligne ── */
  function updateOnlineStatus() {
    const isOnline = navigator.onLine;
    let indicator  = document.getElementById('bn-offline-bar');

    if (!isOnline) {
      if (!indicator) {
        indicator    = document.createElement('div');
        indicator.id = 'bn-offline-bar';
        indicator.innerHTML = `
          <div style="
            position:fixed;top:0;left:0;right:0;z-index:9998;
            background:#e53e3e;color:white;
            padding:8px 16px;text-align:center;
            font-family:system-ui,sans-serif;font-size:13px;font-weight:600;
            display:flex;align-items:center;justify-content:center;gap:8px;
          ">
            <span>📶</span>
            <span>Hors ligne — Vos données locales restent disponibles</span>
          </div>
        `;
        document.body.appendChild(indicator);
        document.body.style.paddingTop = (parseInt(document.body.style.paddingTop)||0) + 38 + 'px';
      }
    } else {
      if (indicator) {
        indicator.remove();
        document.body.style.paddingTop = '';
        showToastPWA('✅ Connexion rétablie !');
      }
    }
  }

  window.addEventListener('online',  updateOnlineStatus);
  window.addEventListener('offline', updateOnlineStatus);
  updateOnlineStatus();

  /* ── 5. Toast PWA ── */
  function showToastPWA(msg) {
    const t = document.createElement('div');
    t.style.cssText = `
      position:fixed;bottom:80px;left:50%;transform:translateX(-50%) translateY(12px);
      background:#1a3c5e;color:white;padding:11px 20px;
      border-radius:99px;font-family:system-ui,sans-serif;
      font-size:13px;font-weight:600;z-index:9999;
      opacity:0;transition:all .35s ease;
      white-space:nowrap;box-shadow:0 4px 20px rgba(0,0,0,.3);
      pointer-events:none;
    `;
    t.textContent = msg;
    document.body.appendChild(t);
    requestAnimationFrame(() => {
      t.style.opacity   = '1';
      t.style.transform = 'translateX(-50%) translateY(0)';
    });
    setTimeout(() => {
      t.style.opacity   = '0';
      t.style.transform = 'translateX(-50%) translateY(12px)';
      setTimeout(() => t.remove(), 400);
    }, 3000);
  }

  function hideBanner(id) {
    const el = document.getElementById(id);
    if (el) el.remove();
  }

  /* ── 6. Informations sur la session PWA ── */
  const isPWA = window.matchMedia('(display-mode: standalone)').matches
             || window.navigator.standalone === true;
  if (isPWA) {
    localStorage.setItem('bn_pwa_installed', '1');
    console.log('[PWA] Lancée en mode application installée');
  }

  /* ── 7. Demander permission notifications (admin seulement) ── */
  window.requestBNNotifications = async function () {
    if (!('Notification' in window)) return false;
    if (Notification.permission === 'granted') return true;
    const result = await Notification.requestPermission();
    return result === 'granted';
  };

  /* Envoyer une notification locale (sans serveur push) */
  window.sendLocalNotification = function (title, body, url) {
    if (Notification.permission !== 'granted') return;
    const n = new Notification(title, {
      body,
      icon : './icons/icon-192.png',
      badge: './icons/icon-96.png',
      tag  : 'bn-local',
    });
    if (url) n.onclick = () => { window.focus(); window.location.href = url; };
  };

  console.log('[PWA] BoutiqueNtazimba PWA initialisée');
})();
